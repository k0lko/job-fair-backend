package com.JFBRA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobFairBootRezervationApplication {
    public static void main(String[] args) {
        SpringApplication.run(JobFairBootRezervationApplication.class, args);
    }
}
